#!/bin/bash

UNIX=(debain "red hat" ubuntu suse fedora)

#print the whole array
echo "elements of array are 		"${UNIX[*]}



#length of array
echo "length of array 		"${#UNIX[*]}



#element at index 2
echo "element at index 2 		"${#UNIX[2]}



#extracting two elements from position 3 
echo "extracting two elements from position 3 		"${UNIX[*]:3:4}



#replace "ubuntu" with "SCO"
echo "replace "ubuntu" with "SCO" 		" ${UNIX[*]/ubuntu/SCO}



#adding two elements
UNIX=(${UNIX[*]} AIX HP-UX)
echo "dding two elements 		"${UNIX[*]}



#removing 3rd element
unset UNIX[3]
echo "removing 3rd element 		"${UNIX[*]}



#copying elements of UNIX to LINUX
LINUX=(${UNIX[*]})
echo "copying elements of UNIX to LINUX 		"${LINUX[*]}



#concatinate LINUX and UNIX
BASH=(${UNIX[*]} ${LINUX[*]})
echo "UNIX elements are: 		"${UNIX[*]}
echo "LINUX elements are: 		"${LINUX[*]}
echo "concatinate LINUX and UNIX 		"${BASH[*]}



#removing UNIX and LINUX array
unset UNIX[*]
unset LINUX[*]

echo "after removing LINUX array  "${LINUX[*]}
echo "after removing UNIX array  "${UNIX[*]}
