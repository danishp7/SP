#!/bin/bash
if [ $# = 2 ]
then
	var1=`ls -l $1`
	arr=($var1)
	
	echo "owner: "${arr[2]}
	echo "group: "${arr[3]}
	echo "permission: "${arr[0]}
	echo "filename: "$1

	if [ ${arr[2]} = $2 ]
	then
		echo "no cheating case."
	else
		echo "there is cheating case."
	fi
else 
	file1=`ls -l $1`
	file2=`ls -l $3`

	arr1=($file1)
	arr2=($file2)
	
		
	echo "owner: "${arr1[2]}
	echo "group: "${arr1[3]}
	echo "permission: "${arr1[0]}
	echo "filename: "$1
	
	if [ $2 = $4 ]
	then
		echo "there is cheating case. "
	else
		diff $1 $3

		if [ $? = 0 ]
		then 
			echo "there is cheating case. "
		else
			echo "no cheating case. "
		fi	
	fi
	
	echo "owner: "${arr2[2]}
	echo "group: "${arr2[3]}
	echo "permission: "${arr2[0]}
	echo "filename: "$1
	if [ $2 = $4 ]
	then
		echo "there is cheating case. "
	else
 		diff $1 $3
		if [ $? = 0 ]
		then 
			echo "there is cheating case. "
		else 
			echo "no cheating case. "
		fi
	fi	
fi
