#!/bin/bash
a=(`cat f1.txt`)
#content of array
echo ${a[*]}

#length of array
echo ${#a[*]}

#length of 3rd index
echo ${#a[3]}
