#!/bin/bash

if [ $# -eq 0 ]
	
then
	echo "enter first value: "
	read var1
	echo "enter second value: "
	read var2
else
	var1=$1
	var2=$2
fi

	echo "sum is: "
	res=`expr $var1 + $var2`
	echo $res
	
	echo "difference is: "
	res=`expr $var1 - $var2`
	echo $res

	echo "product is: "
	res=`expr $var1 \* $var2`
	echo $res

	echo "dision is: "
	res=`expr $var1 / $var2`
	echo $res

	echo "mod is: "
	res=`expr $var1 % $var2`
	echo $res
