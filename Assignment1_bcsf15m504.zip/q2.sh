#!/bin/bash
var=$1
even=`sed -n 1~2p $var 1>evenfile.txt`
odd=`sed -n 2~2p $var 1>oddfile.txt`

