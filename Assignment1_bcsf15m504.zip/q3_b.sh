#!/bin/bash

is_root(){
var=`id -u`

if [ $var -eq 0 ]
then
return 1

elif [ $var -gt 0 ]
then
return 0

fi
}

is_root
f=$?
if [ $f -eq 1 ]
then 
echo "true"
elif [ $f -eq 0 ]
then
echo "false"
fi
