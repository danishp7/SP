#!/bin/bash
is_lower(){
echo "enter string: "
read str
echo "$str" | awk '{print tolower($0)}'
}
is_lower
