#!/bin/bash
`awk '!seen[$0]++' file.txt > file1.txt`
FILE="file1.txt"
cat $FILE

