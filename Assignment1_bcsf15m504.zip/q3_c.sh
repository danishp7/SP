#!/bin/bash


UserExist(){

echo "enter user name: "
read usr
ex="`grep -c $usr /etc/passwd`"
if [ $ex -eq 1 ]
then
echo "exists."
elif [ $ex -eq 0 ]
then
echo "no such user exists."
fi
}

UserExist
