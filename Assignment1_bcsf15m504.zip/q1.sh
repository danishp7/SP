#!/bin/bash

#for entry in $temp/*
#do
#echo "$entry"
#done
#e="${temp##*.}"
#echo $e
#!/bin/bash
#var=$1

#`mkdir fg`

var=(`ls`)
c=1
for i in ${var[*]}
do
Filext=($(echo ${var[$c]} | awk -F . '{if (NF>1) {print $NF}}'))

echo $Filext >> 1.txt
	for idd in ./
	do
		echo $idd
c=$((c+1))
echo ${Filext[*]}
done

echo "afefa "
sort 1.txt | uniq 1>fi.txt 




